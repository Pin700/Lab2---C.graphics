# grafika_lab2

